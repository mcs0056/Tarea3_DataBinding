package com.conBinding.numerosromanos;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;

public class MainViewModel extends BaseObservable {
    private String numero = "";
    private String resultado = "";

    @Bindable
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
        notifyPropertyChanged(BR.numero);
    }

    @Bindable
    public String getResultado() {
        return resultado;
    }

    public void convertir() {
        try {
            int valor = Integer.parseInt(numero);

            if (valor < 1 || valor > 3999) {
                resultado = "Introduce un número entre 1 y 3999";
            } else {
                resultado = "Resultado: " + Conversor.decimalToRoman(valor);
            }

        } catch (NumberFormatException e) {
            resultado = "Número inválido";
        }

        notifyPropertyChanged(BR.resultado);
    }
}
